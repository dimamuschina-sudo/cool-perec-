<?

echo'
<div class="foot">
';
if($user)
{
echo'
<center>
<small>( <a href="/">Главная</a> | <a href="/chat.html">Чатик</a> | <a href="/setting.html">Настройки</a> )</small>
</center>';
}

$CacheFile = '_system/cache/'.md5('on');

if (!$cache = cache($CacheFile, 10)) {

$On .='
<small><i>Сейчас ростят перцы <b>'.number_format(mysql_result(mysql_query("SELECT COUNT(`id`) FROM `users` WHERE `online` > '".(time() - 2400)."' "), 0)).'</b> чел. ';

save_cache($CacheFile, $On, true);
}

echo $cache;

echo'
<br/>Сейчас '.date("H:i").'msk</i>
<br/>
&copy <a href ="/">'.$_SERVER['HTTP_HOST'].'</a>, '.date("Y").'г.
</small>
</div>
</body>
</html>
';

?>