<?php
echo'<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru">

<head>

<title>'.$title.'</title>

<meta http-equiv="Content-Type" content="application/vnd.wap.xhtml+xml; charset=UTF-8" />
<meta name="revisit" content="60 minutes"/>

<link rel="stylesheet" href="/style/style.css" type="text/css"/>
<link rel="shortcut icon" href="/style/favicon.ico" type="image/x-icon"/>

</head>
	
<body>';

if(!$user)
{

echo'<div class="head"><center><a href ="/"><img src = "/images/logo.png" alt="logo"/></a></center></div>';

}else{

echo'
<div class="head"><center>
<img src = "/images/icon/money.png" alt="money"/> '.number_format($user['money']).' 
 <img src = "/images/icon/up.png" alt="up"/> '.($user['mm']/10).' sm';

if($user['time_water'] > time())
{
echo' <img src="/images/pwater.png" width="16" height="16"/> '.maketime($user['time_water']-time());
}
if($user['time_sun'] > time())
{
echo' <img src="/images/psun.png" width="16" height="16"/> '.maketime($user['time_sun']-time());
}
if($user['time_rast'] > time())
{
echo' <img src="/images/prast.png" width="16" height="16"/> '.maketime($user['time_rast']-time());
}

echo'</center></div>';

}



$jurnal_count = mysql_result(mysql_query("SELECT COUNT(`id`) FROM `jurnal` WHERE `user`='$user[id]' AND `chek`='1' "),0);

if($jurnal_count > '0') 
{
echo "<img class='pepper_mini' src = '/images/pepper_mini.png' alt='pepper_mini'/>
<div class='info'>У тебя <b>$jurnal_count</b> <i><a href='/jurnal.html'>Новых событий</a></i> в игре.</div><br/>";
}

echo'</div><br/>';

?>