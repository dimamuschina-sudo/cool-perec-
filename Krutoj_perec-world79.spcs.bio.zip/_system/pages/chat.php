<? 
if (!defined('pepper')) {
	exit('Access Denied');
} else if (!$user) {
	header('Location:/login.html');
	exit;
}

require_header('Чатик');

if($user['location'] != 'chat')
{
 mysql_query("UPDATE `users` SET `location`='chat' WHERE `id`='$user[id]' ");
}

if(isset($_POST['msg'])){

if(mysql_result(mysql_query("SELECT COUNT(`id`) FROM `chat` WHERE `msg` = '".mysql_real_escape_string($_POST['msg'])."' AND `user` = '$user[id]' LIMIT 1"),0)!=0)
{
echo" 
<img class='pepper_mini' src = '/images/pepper_mini.png' alt='pepper_mini'/>
<div class='info'>
Сообщение повторяет предыдущее
</div>";
$err = '1';
}

$msg = htmlspecialchars(strip_tags(trim($_POST['msg'])));

if($msg == NULL)
{
echo"
<img class='pepper_mini' src = '/images/pepper_mini.png' alt='pepper_mini'/>
<div class='info'>
Слишком короткое сообщение </div>";
$err = '1';
}
if(!isset($err))
{
mysql_query("INSERT INTO `chat`(`user`,`msg`,`time`) VALUES('".$user['id']."','".mysql_real_escape_string($msg)."','".time()."')");
header('Location:/chat.html');
}
}

if($user['mm'] < '14')
{ 
echo "<img class='pepper_mini' src = '/images/pepper_mini.png' alt='pepper_mini'/>
<div class='info'>Писать в чат можно от 1.4sm</div>";

}else{

echo" 
<div class='quick'>
<br/>
<center>

<form method='post' action='/chat.html'>

<input name='msg' value=''/> <input type='submit' class='submit' value='Отправить'> <a href='/smiles.html'> Смайлики</a>

</form>


</center>
</div><br/>";
}


echo"<div class='quick'>
<br/>
<center>
В чатике сейчас <b>".number_format(mysql_result(mysql_query("SELECT COUNT(`id`) FROM `users` WHERE `online` > '".(time() - 240)."' AND `location` = 'chat' "), 0))."</b> чел.
</center>
<br/>
";


$chat_count = mysql_result(mysql_query('SELECT COUNT(`id`) FROM `chat`'),0);

if($chat_count == '0') echo 'В чате еще никто не писал. Будь первым :)';


$chat = mysql_query("SELECT * FROM `chat` ORDER BY `id` DESC LIMIT $chat_count");

while ($chatm = mysql_fetch_assoc($chat)){

echo user($chatm['user']).' <small><i>('.online($chatm['user']).')</i></small>  <i>('.date("H:i:s", $chatm['time']).')</i>
'.user_status($chatm['user']).'<br/>  <i>'.output_text($chatm['msg']).'</i><br/><br/>';

$i++;
if($i >= '10')
{
mysql_query("DELETE FROM `chat` WHERE `id`='$chatm[id]' ");
}

}
echo'</div>';





require_footer();

?>