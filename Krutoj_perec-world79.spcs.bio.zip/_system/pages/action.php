<?
if (!defined('pepper')) {
	exit('Access Denied');
} else if (!$user) {
	header('Location:/login.html');
	exit;
}

require_header('Выполняем действие');

if($act == 'water')
{

if($user['time_water'] < time())
{
echo'
<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper"/>
<div class="info">
Полив перца, +0.2sm<br/>
Следующий полив через 2часа...
<br/> Жди 5 сек...
</div>
';

if($_SESSION['training'] == 'water')
{
$_SESSION['training'] = 'sun';
}

mysql_query("UPDATE `users` SET `time_water`='".(time()+7200)."', `mm`=(`mm`+2) WHERE `id`='$user[id]' ");

}else{
echo'
<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper"/>
<div class="info">
Нельзя так часто поливать...<br/>
Приходи через '.maketime($user['time_water']-time()).'
<br/> Жди 5 сек...
</div>
';

}
header('Refresh: 5, url=/index.php');

$yes = 'ok';

}

////////////////////////////////////////////////////////////////////////////////////////
if($act == 'sun')
{

if($user['time_sun'] < time())
{
echo'
<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper"/>
<div class="info">
Согревание перца, +0.7sm<br/>
Следующий согревание через 5часов...
<br/> Жди 5 сек...
</div>
';

if($_SESSION['training'] == 'sun')
{
$_SESSION['training'] = 'rast';
}

mysql_query("UPDATE `users` SET `time_sun`='".(time()+18000)."', `mm`=(`mm`+7) WHERE `id`='$user[id]' ");

}else{
echo'
<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper"/>
<div class="info">
Нельзя так часто согревать...<br/>
Приходи через '.maketime($user['time_sun']-time()).'
<br/> Жди 5 сек...
</div>
';

}
header('Refresh: 5, url=/index.php');
$yes = 'ok';

}

///////////////////////////////////////////////////////////////////////////
if($act == 'rast')
{

if($user['time_rast'] < time())
{
echo'
<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper"/>
<div class="info">
Удобрение перца, +0.5sm<br/>
Следующий удобрение через 3часа...
<br/> Жди 5 сек...
</div>
';

if($_SESSION['training'] == 'rast')
{
$_SESSION['training'] = 'ok';
}

mysql_query("UPDATE `users` SET `time_rast`='".(time()+10800)."', `mm`=(`mm`+5) WHERE `id`='$user[id]' ");

}else{
echo'
<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper"/>
<div class="info">
Нельзя так часто удобрять...<br/>
Приходи через '.maketime($user['time_rast']-time()).'
<br/> Жди 5 сек...
</div>
';

}
header('Refresh: 5, url=/index.php');
$yes = 'ok';

}

/////////////////////////////////////////////////////////////////////////////////
if($act == 'minimize' && $id != '')
{

if ($user['id'] == $id){
header('Location:/');
exit;
}

if($ank = mysql_fetch_assoc(mysql_query("SELECT `nick`,`mm` FROM `users` WHERE `id`='$id' ")))
{

if($ank['mm'] < '30')
{
echo'
<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper"/>
<div class="info">
Нельзя уменьшать перцы которые менее 3sm.
<br/> Жди 5 сек...
</div>
';
}
else
if($user['time_minimize'] < time())
{
echo'
<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper"/>
<div class="info">
Уменьшаем перец...<br/>
+0.1sm к твоему перцу, -0.3sm перца <b>'.$ank['nick'].'</b><br/>
Следующий раз ты сможеш уменьшить комуто перец только через 24ч.
</div>
';


mysql_query("INSERT INTO `jurnal` SET `msg`='<b>$user[nick]</b> уменьшил тебе перец на -0.3sm.', `user`='$id'");
mysql_query("UPDATE `users` SET `mm`=(`mm`-3) WHERE `id`='$id' ");
mysql_query("UPDATE `users` SET `time_minimize`='".(time()+86400)."', `mm`=(`mm`+1) WHERE `id`='$user[id]' ");

}else{
echo'
<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper"/>
<div class="info">
Нельзя так часто уменьшать перцы другим...<br/>
Следующий раз через  '.maketime($user['time_rast']-time()).'
<br/> Жди 5 сек...
</div>
';

}
header('Refresh: 5, url=/user.html/id.'.$id);

$yes = 'ok';
}
}

////////////////////////////////////////////////////////////////////////////////
if(!$yes)
{
header('Location:/');
exit;
}

////////////////////////////////////////////////////////////////////////////////
require_footer();

?>