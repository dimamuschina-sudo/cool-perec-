<?
if (!defined('pepper')) {
	exit('Access Denied');
} else if (!$user) {
	header('Location:/login.html');
	exit;
}

require_header('Сохранение аккаунта');

if($user['password'] == md5('0'))
{

if (isset($_POST['password'])) {

if (preg_match("#^[a-zA-Z0-9\-_\s]{5,12}$#i", trim($_POST['password']))) 
 {

mysql_query("UPDATE `users` SET `password` = '".md5($_POST['password'])."', `money` = (`money`+5) WHERE `id` = '$user[id]'");
$_SESSION['password'] = md5($_POST['password']);		
header('Location: /');
		
}else{
	
echo'<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper_mini"/>
<div class="info">  Ошибочка, присутствуют запрещенные символы!</div>';

}
	
}else{

echo'<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper_mini"/>
<div class="info">  Ты сделал первые шаги, <br/>теперь чтоб сохранить аккаунт придумай пароль.<br/>
Ты получиш награду 5 money.
</div>
';
}
echo'
<div class="quick">
<br/>
<center>
<form action="/save.html" method="post">
	Пароль:<br/>
	<input type="text" name="password" maxlength="13" required/><br/>
	
	<input type="submit" value="Сохранить"/>
</form>
</center>

</div>
';

}else{

header('Location:/');
exit;

}

require_footer();

?>