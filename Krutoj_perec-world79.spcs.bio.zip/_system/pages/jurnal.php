<? 

if (!defined('pepper')) {
	exit('Access Denied');
} else if (!$user) {
	header('Location:/login.html');
	exit;
}


require_header('Журнал событий');

echo " 
<div class='quick'>";

mysql_query("UPDATE `jurnal` SET `chek`= '0'  WHERE `user` ='$user[id]'");

$jurnal_count = mysql_result(mysql_query("SELECT COUNT(`id`) FROM `jurnal` WHERE `user`='$user[id]' "),0);

if($jurnal_count==0) echo 'Пусто...';


$jurnal = mysql_query("SELECT * FROM `jurnal` WHERE `user`='$user[id]' ORDER BY `id` DESC LIMIT 10");

while ($jurnals = mysql_fetch_assoc($jurnal))
{

$i++;

echo ' <i>'.$i.'.</i>  '.$jurnals['msg'].' <small>('.date("j:d:y в H:i:s",$jurnals['time']).')</small>><br/>';

if($i >= '10')
{
mysql_query("DELETE FROM `jurnal` WHERE `id`='$jurnals[id]' ");
}

}
echo'</div>';
echo " 
<div class='quick'>
<i>Показывается только 10 последних записей.</i>
</div>
";


require_footer();
?>