<?php
if (!defined('pepper')) {
	exit('Access Denied');
} else if (!$user) {
	header('Location:/login.html');
	exit;
}

require_header('Выход');

if(isset($act) && $act == 'step4'){

session_destroy();
header('Location: /');
}


if(isset($act) && $act == 'step3'){
echo "<img class='pepper_mini' src = '/images/pepper_mini.png' alt='pepper'/>
<div class='info'>Мы будем ждать тебя снова!<br/><br/>
<a href='/exit.html/step4/'>Выход</a><br/></div>";
require_footer();
}
if(isset($act) && $act == 'step2'){
echo "<img class='pepper_mini' src = '/images/pepper_mini.png' alt='pepper'/>
<div class='info'>Может всё таки останешся?<br/>
<br/><a href='/'>Да, останусь</a>  <a href='/exit.html/step3/'>Нет</a><br/></div>";
require_footer();
}
if(isset($act) && $act == 'step1'){
echo "<img class='pepper_mini' src = '/images/pepper_mini.png' alt='pepper'/>
<div class='info'>Ты в этом уверен?<br/><br/>
<a href='/exit.html/step2/'>Да</a>  <a href='/'>Нет</a><br/></div>";
require_footer();
}
echo "<img class='pepper_mini' src = '/images/pepper_mini.png' alt='pepper'/>
<div class='info'>Так быстро? Ты действительно хотчеш покинуть игру?<br/>
<br/><a href='/exit.html/step1/'>Да, я хочу</a>  <a href='/'>Нет</a><br/></div>";

require_footer();

?>