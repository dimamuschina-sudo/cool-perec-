<? 
if (!defined('pepper')) {
	exit('Access Denied');
} else if (!$user) {
	header('Location:/login.html');
	exit;
}

require_header('Смайлики');

echo"
<img class='pepper_mini' src = '/images/pepper_mini.png' alt='pepper_mini'/>
<div class='info'>
Вот такие смайлики ты можеш использовать...<br/>
<table border='0' cellspacing='10' cellpadding='10'  >
<tr>
<td>
:) -  ".output_text(':)')."<br/>
:( -  ".output_text(':(')."<br/>
:D -  ".output_text(':D')."<br/>
;) -  ".output_text(':)')."<br/>
;( -  ".output_text(':(')."<br/>
:| -  ".output_text(':|')."<br/>
:Z -  ".output_text(':Z')."<br/>
$) -  ".output_text('$)')."<br/>
:P -  ".output_text(':P')."<br/>
8) -  ".output_text('8)')."<br/>
</td><td>
%) -  ".output_text('%)')."<br/>
:* -  ".output_text(':*')."<br/>
:& -  ".output_text(':&')."<br/>
:> -  ".output_text(':>')."<br/>
:@ -  ".output_text(':@')."<br/>
<) -  ".output_text('<)')."<br/>
:] -  ".output_text(':]')."<br/>
=O -  ".output_text('=O')."<br/>
:lol: -  ".output_text(':lol:')."<br/>
:rofl: -  ".output_text(':rofl:')."<br/>
</td><td>
:bla: -  ".output_text(':bla:')."<br/>
:angel: -  ".output_text(':angel:')."<br/>
:fat: -  ".output_text(':fat:')."<br/>
:green: -  ".output_text(':green:')."<br/>
:red: -  ".output_text(':red:')."<br/>
:roll: -  ".output_text(':roll:')."<br/>
:sweat: -  ".output_text(':sweat:')."<br/>
:slim: -  ".output_text(':slim:')."<br/>
:surprise: -  ".output_text(':surprise:')."<br/>
:wink: -  ".output_text(':wink:')."<br/>
</td></table>
</div>
";

require_footer();
?>
