<? 
if (!defined('pepper')) {
	exit('Access Denied');
} else if (!$user) {
	header('Location:/login.html');
	exit;
}

require_header('Игроки онлайн');

$k_online = mysql_result(mysql_query("SELECT COUNT(`id`) FROM `users` WHERE `online` > '".(time() - 2400)."'"),0);

$k_page = k_page($k_online, 10); 
$page = page($k_page);
$num = 10 * $page - 10;

$CacheFile = '_system/cache/'.md5('online_'.$page);

if (!$cache = cache($CacheFile, 5)) {


if ($k_online == '0')
{
$CacheOn .= '<div class="info">Нет игроков онлайн</div>';
}


$q = mysql_query("SELECT `id`, `mm` FROM `users` WHERE `online` > '".(time() - 2400)."' ORDER BY `online` DESC LIMIT $num, 10");
$CacheOn .= '<div class="quick"><br/>';
while ($ank = mysql_fetch_assoc($q)){

$CacheOn .= '
 Игрок '.user($ank['id']).'</a> <i>(Перец <b>'.($ank['mm']/10).'</b> sm)</i> '.user_status($ank['id']).'
 <br/><br/>
';
}

$CacheOn .= '</div>';

save_cache($CacheFile, $CacheOn, true);
}
echo $cache;


if ($k_page > 1) {
	navigation('/online.html/', $k_page, $page);
}


require_footer();
?>
