<?
if (!defined('pepper')) {
	exit('Access Denied');
}

require_header('Крутой перец!');

if (!$user)
{
echo'

<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper"/>
<div class="info">
 Привет, друг!<br/>
Крутой Перец - это самая интересная и позитивная игрушка!
<br/>
А что нужно делать в игре? <br/>
Нужно вырастить самый большой и крутой перец! <br/>
Для этого перец необходимо согревать, поливать и кормить.<br/>
Холодный, сухой и голодный долго не протянет, а мертвый перец - это не круто.<br/> 
На этом приключения не заканчиваются, заходи в игру - у нас круто!
<br/>
';

$CacheFile = '_system/cache/'.md5('info_index');

if (!$cache = cache($CacheFile, 10)) {

$CacheInf .= '<center><ins><i>Сейчас ростят перцы <b>'.number_format(mysql_result(mysql_query("SELECT COUNT(`id`) FROM `users` WHERE `online` > '".(time() - 2400)."' "), 0)).'</b> чел,
 всего зарегестрировано в игре <b>'.number_format(mysql_result(mysql_query("SELECT COUNT(`id`) FROM `users` "), 0)).'</b> чел.</i></ins></center>
<br/>';

save_cache($CacheFile, $CacheInf, true);
}

echo $cache;

echo'
Присоединяйся! =)
</div>

<div class="quick">
<br/>
<center>
<i>Если ты первый раз сдесь жми </i><br/>
<a href = "/start.html" ><b>НАЧАТЬ ИГРУ!</b></a><br/><br/>
<i>либо жми</i><br/>
<a href = "/login.html" >Залогиниться</a>
<br/></center>
</div>
';
}else{

////////////////////////////////////////////////////////
 
if($user['gift_time'] == '0')
{

if(!isset($_SESSION['training']))
{
$_SESSION['training'] = 'water';
}

if($_SESSION['training'] == 'water')
{
echo'<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper"/>
<div class="info">Рад тебя видеть сдесь!<br/>
Ну что давай для начала пройдеш обучение =) <br/>
Твое первое задание,  <img src="/images/pwater.png" width="16" height="16"/> полить свой перец.</div>
';
}

if($_SESSION['training'] == 'sun')
{
echo'<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper"/>
<div class="info">Отлично!<br/>
Ты прексрасно справился... <br/>
Твое второе задание,  <img src="/images/psun.png" width="16" height="16"/> согреть свой перец.</div>
';
}
if($_SESSION['training'] == 'rast')
{
echo'<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper"/>
<div class="info">Найс!<br/>
Отлично справляешся, да ты проффи =) <br/>
Ну и последние задание,  <img src="/images/prast.png" width="16" height="16"/> удобрить свой перец.</div>
';

}
if($_SESSION['training'] == 'ok')
{
echo'<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper"/>
<div class="info">Молодец!<br/>
Ну на этом все =)<br/>
Я тебя немного обучил, остальное осваивай сам или спрашивай у других игроков в чатике.<br/>
Ааа да и чуть не забыл... если заходить каждый день, будеш получать ежедневный подарок! Также лови бонусы в игре!<br/>
Хорошей игры!!!
</div>
';

mysql_query("UPDATE `users` SET `gift_time` = '".(time()+86400)."' WHERE `id`='$user[id]' ");
unset($_SESSION['training']);
}

//////////////////////////////////////////////////////////
}else 
if($user['gift_time'] < time())
{
$r_mm = mt_rand(1,7);
echo'
<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper"/>
<div class="info">Привет! Твой ежедневный подарок за сегодня '.($r_mm/10).' sm. </br>
Заходи каждый день и получай подарок!<br/>
Приятной игры!
</div>';

mysql_query("UPDATE `users` SET `mm`=(`mm`+$r_mm), `gift_time` = '".(time()+86400)."' WHERE `id`='$user[id]' ");
}


/////////////////////////////////////////////////////////

if($user['location'] != '')
{
 mysql_query("UPDATE `users` SET `location`='' WHERE `id`='$user[id]' ");
}

pepper($user['mm']);

echo'
<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper"/>
<div class="info">
Чтото хочеш сделать?
<br/><br/>
<center>

'.($user['time_water'] > time()?'<span id="tuman"><img src = "/images/pwater.png" alt="water"/></span>':'<a href = "/action.html/water/"><img src = "/images/pwater.png" alt="water"/></a>').'

'.($user['time_sun'] > time()?'<span id="tuman"><img src = "/images/psun.png" alt="sun"/></span>':'<a href = "/action.html/sun/" ><img src = "/images/psun.png" alt="sun"/></a>').'

'.($user['time_rast'] > time()?'<span id="tuman"><img src = "/images/prast.png" alt="rast"/></span>':'<a href = "/action.html/rast/" ><img src = "/images/prast.png" alt="rast"/></a>').'


</center>
</div>

';
echo'
<div class="quick">
<br/>
';
if($user['password'] == md5('0'))
{
echo'<center><a href = "/save.html" ><b>СОХРАНИТЬСЯ</b></a> +5 money.</center><br/>';
}

$CacheFile = '_system/cache/'.md5('index');

if (!$cache = cache($CacheFile, 10)) {


$CacheIndex .= '

<a href = "/chat.html" >Чатик</a> '.number_format(mysql_result(mysql_query("SELECT COUNT(`id`) FROM `users` WHERE `online` > '".(time() - 240)."' AND `location` = 'chat' "), 0)).' чел.
<br/><br/>
<a href = "/rating.html" >Рейтинг перцев</a> '.number_format(mysql_result(mysql_query("SELECT COUNT(`id`) FROM `users` "), 0)).'</b> пер.
<br/><br/>
<a href = "/online.html" >Игроки онлайн</a> '.number_format(mysql_result(mysql_query("SELECT COUNT(`id`) FROM `users` WHERE `online` > '".(time() - 2400)."' "), 0)).'</b> чел.
<br/><br/>
';
save_cache($CacheFile, $CacheIndex, true);
}

echo $cache;

echo'
<a href = "/exit.html" >Выйти из игры</a> ('.$user['nick'].')

</div>';

}
require_footer();

?>