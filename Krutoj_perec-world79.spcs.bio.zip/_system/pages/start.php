<?
if (!defined('pepper')) {
	exit('Access Denied');
} else if ($user) {
	header('Location:/');
	exit;
}

require_header('Начинаем игру');

$ip = mysql_real_escape_string($_SERVER['REMOTE_ADDR']);

if(mysql_num_rows(mysql_query("SELECT (`id`) FROM `users` WHERE `ip`='$ip' "))!=0)
{
echo'<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper"/><div class="info"> Пиу пиу! По моим данным у тебя уже есть аккаунт в игре! Напоминаю, что регистрировать несколько аккаунтов запрещается!</div>'; 

}else{

if (isset($_POST['nick'])) {

if ((preg_match("#^[a-zA-Z0-9\-_\s]{3,19}$#i", trim($_POST['nick'])) || preg_match("#^[а-яА-Я0-9\-_\s]{3,19}$#i", trim($_POST['nick']))) 
 && (mysql_num_rows(mysql_query("SELECT (`id`) FROM `users` WHERE `nick`='".mysql_real_escape_string($_POST['nick'])."' LIMIT 1"))) != '1') {


   mysql_query("INSERT INTO `users` SET `nick`='".mysql_real_escape_string($_POST['nick'])."', `password`='".md5('0')."', `ip`='$ip' ", $db);
   
	$SQLID = mysql_insert_id($db);
		$_SESSION = array(
			'id' => $SQLID,
			'password' => md5('0')
		);
		
header('Location: /');
		
}else{
	
echo'

<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper"/><div class="info">  Ошибочка, присутствуют запрещенные символы <br/> или такой никнейм уже есть!</div>';

}
	
}else{

echo'
<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper"/>
<div class="info">  Придумай себе никнейм, он будет отображаться в игре!
<br/>
PS. Никнеймы с нецензурными словами улетают сразу в <b>БАН!</b></div>
';
}
echo'
<div class="quick">
<br/>
<center>
<form action="/start.html" method="post">
Никнейм:<br/>
	<input type="text" name="nick" maxlength="20" required/><br/>
	
	<input type="submit" value="В игру!"/>
</form>
</center>

</div>
';
}

require_footer();

?>