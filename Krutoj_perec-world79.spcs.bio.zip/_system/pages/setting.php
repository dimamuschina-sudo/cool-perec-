<?
if (!defined('pepper')) {
	exit('Access Denied');
} else if (!$user) {
	header('Location:/login.html');
	exit;
}

require_header('Личное меню');
echo'<div class="quick">
<br/>
<a href = "/setting.html/msg/" > Статус / Сообщение на стр. </a>
<a href = "/setting.html/name/" > Имя </a>
<a href = "/setting.html/password/" > Сменить пароль </a>
<a href = "/setting.html/mail/" > E-mail </a>
<br/>
</div>
';

//////////////////////////////////////////////////////////////////////
if($act == 'msg')
{

if(isset($_POST['msg']))
{
$msg = htmlspecialchars(strip_tags(trim($_POST['msg'])));
mysql_query("UPDATE `users` SET `msg` = '$msg'  WHERE `id` = '".mysql_real_escape_string($user['id'])."'");
header('Location:/setting.html/msg/');
exit;
}

echo'<div class="quick">
<center>
<br/>
Сообщение на личной стр. (max.100): <br/>
<form method="post" action="/setting.html/msg/">
<input name="msg" value="'.$user['msg'].'"/>
<br/>
<input type="submit" class="submit" value="Сохранить">
</center>
</div>';

}
/////////////////////////////////////////////////////////////////////
if($act == 'name')
{

if(isset($_POST['name']))
{
$name = htmlspecialchars(strip_tags(trim($_POST['name'])));
mysql_query("UPDATE `users` SET `name` = '$name'  WHERE `id` = '".mysql_real_escape_string($user['id'])."'");
header('Location:/setting.html/name/');
exit;
}

echo'<div class="quick">
<center>
<br/>
Ваше имя: <br/>
<form method="post" action="/setting.html/name/">
<input name="name" value="'.$user['name'].'"/>
<br/>
<input type="submit" class="submit" value="Сохранить">
</center>
</div>';

}
/////////////////////////////////////////////////////////////////////
if($act == 'password')
{

if (isset($_POST['password'])) {

if (preg_match("#^[a-zA-Z0-9\-_\s]{5,12}$#i", trim($_POST['password']))) 
{

mysql_query("UPDATE `users` SET `password` = '".md5($_POST['password'])."' WHERE `id` = '$user[id]'");
$_SESSION['password'] = md5($_POST['password']);		
header('Location: /setting.html/password/');
		
}else{
	
echo'<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper_mini"/>
<div class="info">  Ошибочка, присутствуют запрещенные символы!</div>';

}
	
}

echo'

<div class="quick">
<br/>
<center>
Сменить пароль:<br/>
<form action="/setting.html/password/" method="post">
	
	<input type="text" name="password" maxlength="13" /><br/>
	
	<input type="submit" value="Сохранить"/>
</form>
</center>

</div>
';

}
/////////////////////////////////////////////////////////////////////
if($act == 'mail')
{

if($user['mail'] != '')
{

echo'

<div class="quick">
<br/>
<center>
<i>Майл можно заполнить только 1 раз.</i>
<br/>
E-mail:<br/>

	
<input type="text" name="mail" maxlength="20" value="'.$user['mail'].'" block/><br/>
	
</form>
</center>

</div>
';

}
else
{
if (isset($_POST['mail'])) {

if (preg_match("|^([a-z0-9_\.\-]{1,20})@([a-z0-9\.\-]{1,20})\.([a-z]{2,4})$|ius", trim($_POST['mail']))) 
{

mysql_query("UPDATE `users` SET `mail` = '".mysql_real_escape_string($_POST['mail'])."' WHERE `id` = '$user[id]'");
		
header('Location:/setting.html/mail/');
		
}else{
	
echo'<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper_mini"/>
<div class="info">  Ошибочка, присутствуют запрещенные символы!</div>';

}
	
}

echo'

<div class="quick">
<br/>
<center>
<i>Майл можно заполнить только 1 раз.</i>
<br/>
E-mail:<br/>
<form action="/setting.html/mail/" method="post">
	
	<input type="text" name="mail" maxlength="20" /><br/>
	
	<input type="submit" value="Сохранить"/>
</form>
</center>

</div>
';

}
}

require_footer();

?>