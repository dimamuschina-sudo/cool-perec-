<?
if (!defined('pepper')) {
	exit('Access Denied');
} else
 if (!$user) {
	header('Location:/login.html');
	exit;
}else
 if ($user['id'] == $id){
header('Location:/');
exit;
}


if(mysql_num_rows($sql = mysql_query("SELECT * FROM `users` WHERE `id` = '".mysql_real_escape_string($id)."' LIMIT 1")) != '1')
{ 

header('Location:/');
exit;

}else{
$ank = mysql_fetch_assoc($sql);

require_header($ank['nick']);

echo'
<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper"/>
<div class="info">
Ты на личной страничке <b>'.$ank['nick'].'</b>
<br/>
в данный момент он(а) '.online($ank['id']).'
<br/>
'.user_status($ank['id']);

if($ank['name'] != '') echo'зовут '.output_text($ank['name']);

echo'</div>';

if($ank['msg'] != '') echo'<div class="quick"><center>'.output_text($ank['msg']).'</center></div><br/>';

pepper($ank['mm']);

echo'
<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper"/>
<div class="info">
Чтото хочеш сделать?
<br/><br/>
<center>

'.($user['time_minimize'] > time()?'<span id="tuman"><img src = "/images/minimize.png" alt="minimize"/></span>':'<a href = "/action.html/minimize/id.'.$ank['id'].'"><img src = "/images/minimize.png" alt="minimize"/></a>').'



</center>
</div>

';


require_footer();
}
?>