<?
if (!defined('pepper')) {
	exit('Access Denied');
} else if ($user) {
	header('Location:/');
	exit;
}

require_header('Логинимся');

if (isset($_POST['nick'], $_POST['password'])) {
	if (mysql_num_rows($sql = mysql_query("SELECT (`id`) FROM `users` WHERE `nick`='".mysql_real_escape_string($_POST['nick'])."' AND `password`='".md5(mysql_real_escape_string($_POST['password']))."' LIMIT 1", $db))) 
	{
   
   $id = mysql_result($sql, 0);
   $ip = mysql_real_escape_string($_SERVER['REMOTE_ADDR']);
   
	mysql_query("UPDATE `users` SET `ip`='$ip' WHERE `id`='$id' ");
	
		$_SESSION = array(
			'id' => $id,
			'password' => md5($_POST['password'])
		);
		
header('Location: /');
		
}else{
	
echo'
<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper_mini"/>
<div class=info>  Ошибочка чтото ты ввел нето!</div>';

}
	
}else{

echo'
<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper_mini"/>
<div class="info">
  Введи свой данные чтобы залогиниться.
</div>

';

}

echo'
<div class="quick">
<br/>
<center>
<form action="login.html" method="post">
	Никнейм:<br/>
	<input type="text" name="nick" maxlength="30" required/><br/>
	Пароль:<br/>
	<input type="password" name="password" maxlength="20" required/><br/>
	<input type="submit" value="Залогиниться"/>
</form>
</center>
</div>
';


require_footer();

?>