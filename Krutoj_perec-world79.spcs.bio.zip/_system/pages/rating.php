<? 
if (!defined('pepper')) {
	exit('Access Denied');
} else if (!$user) {
	header('Location:/login.html');
	exit;
}

require_header('Рейтинг перцев');

$k_users = mysql_result(mysql_query("SELECT COUNT(`id`) FROM `users`"),0);

$k_page = k_page($k_users, 10); 
$page = page($k_page);
$num = 10 * $page - 10;


$CacheFile = '_system/cache/'.md5('rating_'.$page);

if (!$cache = cache($CacheFile, 5)) {


if ($k_online == '0')
{
$CacheRat .= '<img class="pepper_mini" src = "/images/pepper_mini.png" alt="pepper"/>
<div class="info">Топ пуст</div>';
}



$q = mysql_query("SELECT `id`, `mm` FROM `users` ORDER BY `mm` DESC LIMIT $num, 10");
$CacheRat .= '<div class="quick"><br/>';
while ($ank = mysql_fetch_assoc($q)){
$num++;
				 
$CacheRat .= '<b>№'.$num.'</b> - Перец <b>'.($ank['mm']/10).'</b> sm, хозяин
 '.user($ank['id']).'</a> <i>('.online($ank['id']).')</i>'.user_status($ank['id']).'

 <br/><br/>
';

}

$CacheRat .= '</div>';

save_cache($CacheFile, $CacheRat, true);
}

echo $cache;

if ($k_page > 1) {
	navigation('/rating.html/', $k_page, $page);
}

require_footer();
?>
