<?
header('location: /');
?>	